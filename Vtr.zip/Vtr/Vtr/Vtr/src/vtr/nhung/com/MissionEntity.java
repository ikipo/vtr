package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;
import java.lang.String;

public class MissionEntity
{
private String id;
private String ten;
private String idnhanvatmuctieu;
private String nguyenvong;
// danh sach diem dat hoan thanh nhiem vu
private ThuoctinhEntity thuoctinh;
	
	public MissionEntity()
	{
	this.id = "";
	this.ten = "";
	this.idnhanvatmuctieu = "";
	this.nguyenvong = "";
	this.thuoctinh = new ThuoctinhEntity (id);
	}
	public void MissionEntity (String id, String ten, String idnhanvatmuctieu, String nguyenvong, ThuoctinhEntity thuoctinh){	
	this.id = id;
	this.ten = ten;
	this.idnhanvatmuctieu = idnhanvatmuctieu;
	this.nguyenvong = nguyenvong;
	this.thuoctinh = thuoctinh;
	}
	public void setId (String id){this.id = id;}
	public void setTen (String ten){this.ten = ten;}
	public void setIdnhanvatmuctieu (String idnhanvatmuctieu){this.idnhanvatmuctieu = idnhanvatmuctieu;}
	public void setNguyenvong (String nguyenvong){this.nguyenvong = nguyenvong;}
	
	public String getId (){return id;}
	public String getTen (){return ten;}
	public String getIdnhanvatmuctieu (){return idnhanvatmuctieu;}
	public String getNguyenvong (){return nguyenvong;}
	
}
