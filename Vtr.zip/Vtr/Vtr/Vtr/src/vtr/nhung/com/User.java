package vtr.nhung.com;

public class User
{
	public User()
	{
	}
}
