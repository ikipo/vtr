package vtr.nhung.com;

public class Chiso
{
private int id;
private String ten,mota;

	public Chiso()
	{
	}
	
	public Chiso (String ten, String mota) {
	this.ten = ten;
	this.mota = mota;
	}
	
	public void setId (int id) {this.id = id;}
	public void setTen (String ten) {this.ten = ten;}
	public void setMota (String mota) {this.mota = mota;}
	public int getId (){return this.id;}
	public String getTen (){return this.ten;}
	public String getMota (){return this.mota;}
}
