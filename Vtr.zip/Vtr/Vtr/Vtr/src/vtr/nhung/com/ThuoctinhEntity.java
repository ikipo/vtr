package vtr.nhung.com;

public class ThuoctinhEntity
{
private String id;
// Thuoc tinh
private int hachoa;
private int haocam;
private int tincay;
private int hailong;
private int miluc;
private int voluc;
private int danhvong;
private int giausang;
private int tinhyeu;
private int haucung;
private int daohoa;
private int xinhdep;
private int thongminh;
private int kheoleo;
private int noitieng;
private int quyenluc;
private int tudo;
private int tra;
private int tien;
private int bachlienhoa;
private int thanhmau;
private int marysure;
private int thientai;
private int amap;
private int nguytrang;
private int ngaytho;
	public ThuoctinhEntity(String id)
	{
	this.id = id;
	this.hachoa = 0;
	this.haocam = 0;
	this.tincay = 0;
	this.hailong = 0;
	this.miluc = 0;
	this.voluc = 0;
	this.danhvong = 0;
	this.giausang = 0;
	this.tinhyeu = 0;
	this.haucung = 0;
	this.daohoa = 0;
	this.xinhdep = 0;
	this.thongminh = 0;
	this.kheoleo = 0;
	this.noitieng = 0;
	this.quyenluc = 0;
	this.tudo = 0;
	this.tra = 0;
	this.tien = 0;
	this.bachlienhoa = 0;
	this.thanhmau = 0;
	this.marysure = 0;
	this.thientai = 0;
	this.amap = 0;
	this.nguytrang = 0;
	this.ngaytho = 0;
	}
	public void ThuoctinhEntity (String id, int hachoa, int haocam, int tincay, int hailong, int miluc, int voluc, int danhvong, int giausang, int tinhyeu, int haucung, int daohoa, int xinhdep, int thongminh, int kheoleo, int noitieng, int quyenluc, int tudo, int tra, int tien, int bachlienhoa, int thanhmau, int marysure, int thientai, int amap, int nguytrang, int ngaytho){
	this.id = id;
	this.hachoa = hachoa;
	this.haocam = haocam;
	this.tincay = tincay;
	this.hailong = hailong;
	this.miluc = miluc;
	this.voluc = voluc;
	this.danhvong = danhvong;
	this.giausang = giausang;
	this.tinhyeu = tinhyeu;
	this.haucung = haucung;
	this.daohoa = daohoa;
	this.xinhdep = xinhdep;
	this.thongminh = thongminh;
	this.kheoleo = kheoleo;
	this.noitieng = noitieng;
	this.quyenluc = quyenluc;
	this.tudo = tudo;
	this.tra = tra;
	this.tien = tien;
	this.bachlienhoa = bachlienhoa;
	this.thanhmau = thanhmau;
	this.marysure = marysure;
	this.thientai = thientai;
	this.amap = amap;
	this.nguytrang = nguytrang;
	this.ngaytho = ngaytho;
	}
	public void setId (String id){this.id = id;}
	public String getId (){return id;}
	public void setHachoa (int hachoa){this.hachoa = hachoa;}
	public void setHaocam (int haocam){this.haocam = haocam;}
	public void setTincay (int tincay){this.tincay = tincay;}
	public void setHailong (int hailong){this.hailong = hailong;}
	public void setMiluc (int miluc){this.miluc = miluc;}
	public void setVoluc (int voluc){this.voluc = voluc;}
	public void setDanhvong (int danhvong){this.danhvong = danhvong;}
	public void setGiausang (int giausang){this.giausang = giausang;}
	public void setTinhyeu (int tinhyeu){this.tinhyeu = tinhyeu;}
	public void setHaucung (int haucung){this.haucung = haucung;}
	public void setDaohoa (int daohoa){this.daohoa = daohoa;}
	public void setXinhdep (int xinhdep){this.xinhdep = xinhdep;}
	public void setThongminh (int thongminh){this.thongminh = thongminh;}
	public void setKheoleo (int kheoleo){this.kheoleo = kheoleo;}
	public void setNoiteng (int noitieng){this.noitieng = noitieng;}
	public void setQuyenluc (int quyenluc){this.quyenluc = quyenluc;}
	public void setTudo (int tudo){this.tudo = tudo;}
	public void setTra (int tra){this.tra = tra;}
	public void setTien (int tien){this.tien = tien;}
	public void setBachlienhoa (int bachlienhoa){this.bachlienhoa = bachlienhoa;}
	public void setThanhmau (int thanhmau){this.thanhmau = thanhmau;}
	public void setMarysure (int marysure){this.marysure = marysure;}
	public void setThientai (int thientai){this.thientai = thientai;}
	public void setAmap (int amap){this.amap = amap;}
	public void setNguytrang (int nguytrang){this.nguytrang = nguytrang;}
	public void setNgaytho (int ngaytho){this.ngaytho = ngaytho;}
	
	public int getHachoa (){return hachoa;}
	public int getHaocam (){return haocam;}
	public int getTincay (){return tincay;}
	public int getHailong (){return hailong;}
	public int getMiluc (){return miluc;}
	public int getVoluc (){return voluc;}
	public int getDanhvong (){return danhvong;}
	public int getGiausang (){return giausang;}
	public int getTinhyeu (){return tinhyeu;}
	public int getHaucung (){return haucung;}
	public int getDaohoa (){return daohoa;}
	public int getXinhdep (){return xinhdep;}
	public int getThongminh (){return thongminh;}
	public int getKheoleo (){return kheoleo;}
	public int getNoiteng (){return noitieng;}
	public int getQuyenluc (){return quyenluc;}
	public int getTudo (){return tudo;}
	public int getTra (){return tra;}
	public int getTien (){return tien;}
	public int getBachlienhoa (){return bachlienhoa;}
	public int getThanhmau (){return thanhmau;}
	public int getMarysure (){return marysure;}
	public int getThientai (){return thientai;}
	public int getAmap (){return amap;}
	public int getNguytrang (){return nguytrang;}
	public int getNgaytho (){return ngaytho;}
	
}
