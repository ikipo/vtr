package vtr.nhung.com;
import vtr.nhung.com.StartActivity;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.R.drawable;
import java.lang.Override;
import android.content.Intent;
import android.R.layout;
import android.R.id;

public class UserInfoActivity extends Activity
{
Button btn;
	@Override
	public void onCreate (Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main3);
	btn = (Button)findViewById(R.id.btna);
	btn.setOnClickListener(new View.OnClickListener (){
	    public void onClick (View v){
	    Toast.makeText(UserInfoActivity.this,"hdvsf",Toast.LENGTH_SHORT).show();
	    Intent i = new Intent (UserInfoActivity.this,StartActivity.class);
	    startActivity (i);
	    }
	});
	}
}
