package vtr.nhung.com;
import android.content.Context;
import vtr.nhung.com.DataBaseHelper;
import android.database.sqlite.SQLiteDatabase;
import android.database.SQLException;
import java.io.IOException;
import android.util.Log;
import java.lang.Error;
import android.database.Cursor;
import java.lang.Exception;

public class DataAdapter
{
public static final String TAG = "DataAdapter";
private final Context mContext;
private SQLiteDatabase mDb;
private DataBaseHelper mDbHelper;
	public DataAdapter(Context context)
	{
	this.mContext = context;
	mDbHelper = new DataBaseHelper (mContext);
	}
	
	public DataAdapter createDatabase () throws SQLException {
	try {
	mDbHelper.createDataBase();
	}catch (IOException e){
	Log.e(TAG, e.toString() + "Unable create database");
	throw new Error("UnableToCreateDatabase");
	}
	return this;
	}
	
	public DataAdapter open() throws SQLException {
	try {
	mDbHelper.openDataBase();
	mDbHelper.close();
	mDb = mDbHelper.getReadableDatabase();
	}catch(SQLException e) {
	
	}
	return this;
	}
	
	public void close (){
	mDbHelper.close();
	}
	
	public Cursor getData(String sql){
	try {
	//String sql = "SELECT * FROM Nhanvat";
	Cursor cursor = mDb.rawQuery(sql,null);
	if (cursor!=null) {
	cursor.moveToNext();
	}
	return cursor;
	}catch (SQLException e){
	Log.e(TAG, "getTestData >>"+ e.toString());
             throw e;
	}
	}
	
}
