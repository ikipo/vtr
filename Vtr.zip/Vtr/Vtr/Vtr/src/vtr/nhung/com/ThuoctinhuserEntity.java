package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;

public class ThuoctinhuserEntity
{
private String id;
private int kinhnghiem;
private int capdo;
private int mayman;
private int miluc;
private int voluc;
private ThuoctinhEntity tiendo;
	public ThuoctinhuserEntity(String id)
	{
	this.id = id;
	this.kinhnghiem = 0;
	this.capdo = 0;
	this.mayman = 0;
	this.miluc = 0;
	this.voluc = 0;
	this.tiendo = new ThuoctinhEntity (id);
	}
	public ThuoctinhuserEntity(String id, int kinhnghiem, int capdo, int mayman, int miluc, int voluc, ThuoctinhEntity tiendo)
	{
	this.id = id;
	this.kinhnghiem = kinhnghiem;
	this.capdo = capdo;
	this.mayman = mayman;
	this.miluc = miluc;
	this.voluc = voluc;
	this.tiendo = tiendo;
	}
	public String getId (){return id;}
	public int getKinhnghiem (){return kinhnghiem;}
	public int getCapdo (){return capdo;}
	public int getMayman (){return mayman;}
	public int getMiluc (){return miluc;}
	public int getVoluc (){return voluc;}
	public ThuoctinhEntity getTiendo (){return tiendo;}
}
