package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;

public class ThuoctinhuserEntity
{
private String id;
private int kinhnghiem;
private int capdo;
private int mayman;
private int miluc;
private int voluc;
private ThuoctinhEntity tiendo;
	public ThuoctinhuserEntity(String id)
	{
	this.id = id;
	}
}
