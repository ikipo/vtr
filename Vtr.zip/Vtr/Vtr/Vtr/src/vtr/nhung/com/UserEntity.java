package vtr.nhung.com;

public class UserEntity
{
private String id;
private String ten;
private int tuoi;
private int kinhnghiem;
private int capdo;
private int mayman;
private int miluc;
private int voluc;
private String [] skills;
//cap do cham theo diem kinh nghiem
private int socap;
private int trungcap;
private int caocap;
private int sieucap;
	public UserEntity()
	{
	}
}
