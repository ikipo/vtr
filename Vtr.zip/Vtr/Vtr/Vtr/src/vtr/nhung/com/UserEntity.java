package vtr.nhung.com;
import vtr.nhung.com.CharacterEntity;

public class UserEntity
{
private String id;
private String ten;
private int tuoi;
private int kinhnghiem;
private int capdo;
private int mayman;
private int miluc;
private int voluc;
private CharacterEntity tiendo;
//cap do cham theo diem kinh nghiem
private int socap;
private int trungcap;
private int caocap;
private int sieucap;
	public UserEntity()
	{
	this.id = "";
    this.ten = "";
    this.tuoi = 15;
	this.socap = 0;
	this.kinhnghiem = 0;
	this.capdo = 0;
	this.mayman = 0;
	this.miluc = 0;
	this.voluc = 0;
	this.trungcap = 10000;
	this.caocap = 100000;
	this.sieucap = 1000000;
	}
	public void UserEntity (String id, String ten, int tuoi, int kinhnghiem, int capdo, int mayman, int miluc, int voluc){
	this.id = id;
	this.ten = ten;
	this.tuoi = tuoi;
	this.kinhnghiem = kinhnghiem;
	this.capdo = capdo;
	this.mayman = mayman;
	this.miluc = miluc;
	this.voluc = voluc;	
	}
	
	public void setId (String id) {
	this.id = id;
	}
	public String getId (){
	return id;
	}
	
	public void setTen(String ten) {
	this.ten = ten;
	}
	public String getTen (){
	return ten;
	}
	
	public void setTuoi (int tuoi) {
	this.tuoi = tuoi;
	}
	public int getTuoi (){
	return tuoi;
	}
	
	public void setKinhnghiem (int kinhnghiem){
	this.kinhnghiem = kinhnghiem;
	}
	public int getKinhnghiem (){
	return kinhnghiem;
	}
	
	public void setCapdo (int capdo) {
	this.capdo = capdo;
	}
	public int getCapdo (){
	return capdo;
	}
	
	public void setMayman (int mayman){
	this.mayman = mayman;
	}
	public int getMayman (){
	return mayman;
	}
	
	public void setMiluc (int miluc) {
	this.miluc = miluc;
	}
	public int getMiluc (){
	return miluc;
	}
}
