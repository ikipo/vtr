package vtr.nhung.com;
import android.app.*;
import android.os.*;

import android.view.*;
import android.widget.*;
import android.R.drawable;
import java.lang.Override;
import android.content.Intent;

public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.main2);
        Handler h = new Handler ();
        h.postDelayed(new Runnable (){
            public void run() {
            Intent i = new Intent (MainActivity.this,UserInfoActivity.class);
            startActivity (i);
            }
        },5000);
     }
	
    @Override
    public void onPause() {
    super.onPause();
    finish ();
    }
}
