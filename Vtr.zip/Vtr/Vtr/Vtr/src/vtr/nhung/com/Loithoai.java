package vtr.nhung.com;

public class Loithoai
{
private int id, idnguongoc, idnhanvatchinh, idnhanvatphu, idkynang, dieukien, idthegioi;
private String tomtat, chitiet;

	public Loithoai()
	{
	}
	
	public Loithoai (int id, int idnguongoc, int idnhanvatchinh, int idnhanvatphu, String tomtat, String chitiet, int idkynang, int dieukien, int idthegioi){
	this.id = id;
	this.idnguongoc = idnguongoc;
	this.idnhanvatchinh = idnhanvatchinh;
	this.idnhanvatphu = idnhanvatphu;
	this.tomtat = tomtat;
	this.chitiet = chitiet;
	this.idkynang = idkynang;
	this.dieukien = dieukien;
	this.idthegioi = idthegioi;
	}
	
	public void setId (int id) {this.id = id;}
	public void setIdnguongoc (int idnguongoc) {this.idnguongoc = idnguongoc;}
	public void setIdnhanvatchinh (int idnhanvatchinh) {this.idnhanvatchinh = idnhanvatchinh;}
	public void setIdnhanvatphu (int idnhanvatphu) {this.idnhanvatphu = idnhanvatphu;}
	public void setTomtat (String tomtat) {this.tomtat = tomtat;}
	public void setChitiet (String chitiet) {this.chitiet = chitiet;}
	public void setIdkynang (int idkynang) {this.idkynang = idkynang;}
	public void setDieukien (int dieukien) {this.dieukien = dieukien;}
	public void setIdthegioi (int idthegioi) {this.idthegioi = idthegioi;}
	
	public int getId (){return this.id;}
	public int getIdnguongoc (){return this.idnguongoc;}
	public int getIdnhanvatchinh (){return this.idnhanvatchinh;}
	public int getIdnhanvatphu (){return this.idnhanvatphu;}
	public String getTomtat (){return this.tomtat;}
	public String getChitiet (){return this.chitiet;}
	public int getIdkynang (){return this.idkynang;}
	public int getDieukien (){return this.dieukien;}
	public int getIdthegioi (){return this.idthegioi;}
	
}
