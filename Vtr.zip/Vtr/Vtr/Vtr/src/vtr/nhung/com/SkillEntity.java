package vtr.nhung.com;

public class SkillEntity
{
private String id;
private String iduser;
private String ten;
private String chitiet;
private int capdo;
// muc cham diem ky nang
private int diemsocap; //capdo1 vd miluc...+0
private int diemtrungcap; //capdo2 miluc...+0+2
private int diemcaocap;//capdo3 miluc...+0+5
// Danh sach diem anh huong den cac thuoc tinh khi ap dung ky nang vd:miluc = +1, voluc=-1
private ThuoctinhuserEntity chodiem;
	public SkillEntity(String id)
	{
	this.id = id;
	this.iduser = "";
	this.ten = "";
	this.chitiet = "";
	this.capdo = 1;
	this.diemsocap = 1;
	this.diemtrungcap = 2;
	this.diemcaocap = 5;
	this.chodiem = new ThuoctinhuserEntity (id);
	}
	public SkillEntity(String id, String iduser, String ten, String chitiet, int capdo, ThuoctinhuserEntity chodiem)
	{
	this.id = id;
	this.iduser = iduser;
	this.ten = ten;
	this.chitiet = chitiet;
	this.capdo = capdo;
	this.diemsocap = 1;
	this.diemtrungcap = 2;
	this.diemcaocap = 5;
	this.chodiem = chodiem;
	}
	public String getId (){return id;}
	public String getIduser (){return iduser;}
	public String getTen (){return ten;}
	public String getChitiet (){return chitiet;}
	public int getCapdo (){return capdo;}
	public int getDiemsocap (){return diemsocap;}
	public int getDiemtrungcap (){return diemtrungcap;}
	public int getDiemcaocap (){return diemcaocap;}
	public ThuoctinhuserEntity getChodiem (){return chodiem;}
	public void setId (String id){this.id = id;}
	public void setIduser (String iduser){this.iduser = iduser;}
	public void setTen (String ten){this.ten = ten;}
	public void setChitiet (String chitiet){this.chitiet = chitiet;}
	public void setCapdo (int capdo){this.capdo = capdo;}
	public void setChodiem (ThuoctinhuserEntity chodiem){this.chodiem = chodiem;}
}
