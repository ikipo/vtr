package vtr.nhung.com;

public class SkillEntity
{
private String id;
private String ten;
private String chitiet;
private int capdo;
// muc cham diem ky nang
private int diemsocap = 0; //capdo1 vd miluc...+0
private int diemtrungcap = 2; //capdo2 miluc...+0+2
private int diemcaocap = 5;//capdo3 miluc...+0+5
// Danh sach diem anh huong den cac thuoc tinh khi ap dung ky nang vd:miluc = +1, voluc=-1
private int hachoa;
private int haocam;
private int tincay;
private int hailong;
private int miluc;
private int voluc;
private int danhvong;
private int giausang;
private int tinhyeu;
private int haucung;
private int daohoa;
private int xinhdep;
private int thongminh;
private int kheoleo;
private int noitieng;
private int quyenluc;
private int tudo;
private int tra;
private int tien;
private int bachlienhoa;
private int thanhmau;
private int marysure;
private int thientai;
private int amap;
private int nguytrang;
private int ngaytho;
	public SkillEntity()
	{
	}
}
