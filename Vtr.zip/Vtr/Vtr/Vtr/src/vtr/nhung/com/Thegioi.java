package vtr.nhung.com;

public class Thegioi
{
private int id,iddieukienchiso;
private String ten,cottruyen,nguyenvong;

	public Thegioi()
	{
	}
	
	public Thegioi (String ten, String cottruyen, String nguyenvong, int iddieukienchiso){	
	this.ten = ten;
	this.cottruyen = cottruyen;
	this.nguyenvong = nguyenvong;
	this.iddieukienchiso = iddieukienchiso;
	}
	
	public int getId (){return this.id;}
	public String getTen (){return this.ten;}
	public String getCottruyen (){return this.cottruyen;}
	public String getNguyenvong (){return this.nguyenvong;}
	public int getIddieukienchiso (){return this.iddieukienchiso;}
	public void setId(int id) {this.id = id;}
	public void setTen(String ten) {this.ten = ten;}
	public void setCottruyen(String cottruyen) {this.cottruyen = cottruyen;}
	public void setNguyenvong(String nguyenvong) {this.nguyenvong = nguyenvong;}
	public void setIddieukienchiso (int iddieukienchiso) {this.iddieukienchiso = iddieukienchiso;}
}
