package vtr.nhung.com;

public class Kynang
{
private int id, idthegioi, giatrikinhnghiem;
private String ten, mota;

	public Kynang()
	{
	}
	
	public Kynang (int id, String ten, String mota, int idthegioi, int giatrikinhnghiem) {
	this.id = id;
	this.ten = ten;
	this.mota = mota;
	this.idthegioi = idthegioi;
	this.giatrikinhnghiem = giatrikinhnghiem;
	}
	
	public void setId (int id) {this.id = id;}
	public void setTen (String ten) {this.ten = ten;}
	public void setMota (String mota) {this.mota = mota;}
	public void setIdthegioi (int idthegioi) {this.idthegioi = idthegioi;}
	public void setGiatrikinhnghiem (int giatrikinhnghiem) {this.giatrikinhnghiem = giatrikinhnghiem;}
	public int getId (){return this.id;}
	public String getTen (){return this.ten;}
	public String getMota (){return this.mota;}
	public int getIdthegioi (){return this.idthegioi;}
	public int getGiatrikinhnghiem (){return this.giatrikinhnghiem;}
}
