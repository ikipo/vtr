package vtr.nhung.com;

public class Dieukienchiso
{
private int id,idthegioi,idnhanvatchinh,idnhanvatphu,idtheloai,idchiso,giatri,idloithoai;
// id theloai : 1 = chinhminh, 2 = chonguoikhac, 3 = chothemchinhminh, 4 = chothemnguoikhac, 5 = dieukiencualoithoai (phu thuoc nhan vat noi co bao nhieu chi so voi nguoi nghe) co nhieu idthoai trung nhau trong bang nay
	
	public Dieukienchiso()
	{
	}
	
	public Dieukienchiso (int idthegioi, int idnhanvatchinh, int idnhanvatphu, int idtheloai, int idchiso, int giatri, int idloithoai) {
	this.idthegioi = idthegioi;
	this.idnhanvatchinh = idnhanvatchinh;
	this.idnhanvatphu = idnhanvatphu;
	this.idtheloai = idtheloai;
	this.idchiso = idchiso;
	this.giatri = giatri;
	this.idloithoai = idloithoai;
	}
	
	public int getId (){return this.id;}
	public int getIdThegioi (){return this.idthegioi;}
	public int getIdnhanvatchinh (){return this.idnhanvatchinh;}
	public int getIdnhanvatphu (){return this.idnhanvatphu;}
	public int getIdtheloai (){return this.idtheloai;}
	public int getIdchiso (){return this.idchiso;}
	public int getIdgiatri (){return this.giatri;}
	public int getIdloithoai (){return this.idloithoai;}
	public void setId (){this.id = id;}
	public void setIdthegioi (){this.idthegioi = idthegioi;}
	public void setIdnhanvatchinh (){this.idnhanvatchinh = idnhanvatchinh;}
	public void setIdnhanvatphu (){this.idnhanvatphu = idnhanvatphu;}
	public void setIdtheloai (){this.idtheloai = idtheloai;}
	public void setIdchiso (){this.idchiso = idchiso;}
	public void setGiatri (){this.giatri = giatri;}
	public void setIdloithoai (){this.idloithoai = idloithoai;}
}
