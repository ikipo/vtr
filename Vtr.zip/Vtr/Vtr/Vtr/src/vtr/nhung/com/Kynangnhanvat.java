package vtr.nhung.com;

public class Kynangnhanvat
{
private int id, idthegioi, idnhanvat, idkynang, capdo;

	public Kynangnhanvat()
	{
	}
	
	public Kynangnhanvat (int idthegioi, int idnhanvat, int idkynang, int capdo) {
	this.idthegioi = idthegioi;
	this.idnhanvat = idnhanvat;
	this.idkynang = idkynang;
	this.capdo = capdo;
	}
	
	public void setId (int id) {this.id = id;}
	public void setIdthegioi (int idthegioi) {this.idthegioi = idthegioi;}
	public void setIdnhanvat (int idnhanvat) {this.idnhanvat = idnhanvat;}
	public void setIdkynang (int idkynang) {this.idkynang = idkynang;}
	public void setCapdo (int capdo) {this.capdo = capdo;}
	public int getId (){return this.id;}
	public int getIdthegioi (){return this.idthegioi;}
	public int getIdnhanvat (){return this.idnhanvat;}
	public int getIdkynang (){return this.idkynang;}
	public int getCapdo (){return this.capdo;}
}
