package vtr.nhung.com;
import vtr.nhung.com.DataAdapter;
import android.database.Cursor;
import android.content.Context;
import java.lang.Exception;
public class GetData
{
Context context;
DataAdapter data;
	public GetData(Context c)
	{
	this.context = c;
	data = new DataAdapter (c);
	}
	
	public String getTest (){
	String result = "";
	data.createDatabase();
	data.open();
	String sql = "SELECT * FROM Nguoichoi";
	Cursor c = data.getData(sql);
	if (c!=null) {
        c.moveToFirst();
        do {
        String str = c.getInt (0)+" -- ";
        str += c.getString (1)+"";
        result = str;
        }while (c.moveToNext());
        }
	return result;
	
	}
	
}
