package vtr.nhung.com;
import vtr.nhung.com.DataBaseHelper;
import vtr.nhung.com.DataAdapter;
import vtr.nhung.com.Thegioi;
import vtr.nhung.com.Kynang;
import vtr.nhung.com.Kynangnhanvat;
import vtr.nhung.com.Nhanvat;
import vtr.nhung.com.Chiso;
import vtr.nhung.com.Chisokynang;
import vtr.nhung.com.Dieukienchiso;
import vtr.nhung.com.Loithoai;
import vtr.nhung.com.Nguoichoi;
import vtr.nhung.com.Nguoichoithegioi;
import android.database.Cursor;
import android.content.Context;
import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;
import java.util.Collection;
import java.util.Collections;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
public class GetData
{
Context context;
DataAdapter data;
private int idthegioi;
	public GetData(Context c)
	{
	this.context = c;
	data = new DataAdapter (c);
	}
	
	public int tongkinhnghiemnguoichoi (){	
	int sum = 0;
	String sql = "select * from Nguoichoithegioi where idnguoichoi like 1";
	data.open();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {	   
	    sum += c.getInt (4);	    	    
	    }while (c.moveToNext());
	}
	data.close();
	return sum;
	}	
	
	public void setIdthegioi (int id){
	this.idthegioi = id;
	}
	
	public int getIdthegioi (){
	
	return this.idthegioi;
	}
	
	public int getIdthoaihientai () {
	int id = 0;
	int id2 = thegioihientai().getIdthoaihientai ();
	id = id2;
	
	return id;
	}
	
	public void setIdthoaihientai (int idthoaihientai){
	data.open();
	DataBaseHelper database = new DataBaseHelper (context);
	SQLiteDatabase db = database.getDb ();
	ContentValues values = new ContentValues ();
	Nguoichoithegioi nctg = thegioihientai ();
	nctg.setIdthoaihientai (idthoaihientai);
	int id = nctg.getId ();
	values.put ("idthoaihientai",idthoaihientai);
	db.update("Nguoichoithegioi",values,"id like '"+id+"'",null);
	data.close ();
	}
		
	public Nguoichoithegioi thegioihientai (){
	Nguoichoithegioi nctg = new Nguoichoithegioi ();
	int kn = tongkinhnghiemnguoichoi();
	int idtg = 0;
	if (kn <1) {
	idtg = 1;
	}else {
	idtg = getIdthegioi ();
	}
	String sql = "select * from Nguoichoithegioi where idthegioi like '"+idtg+"'";
	//data.createDatabase ();
	data.open();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {
	    int n1 = c.getInt (0);
	    int n2 = c.getInt (1);
	    int n3 = c.getInt (2);
	    int n4 = c.getInt (3);
	    int n5 = c.getInt (4);
	    int n6 = c.getInt (5);
	    nctg = new Nguoichoithegioi (n1,n2,n3,n4,n5,n6);
	    }while (c.moveToNext());
	}
	data.close();
	return nctg;
	}
	
	public List <Nhanvat> danhsachnhanvattheothegioi (){	
	int id = 0;
	int idthegioi = thegioihientai().getId ();
	
	String sql = "select * from Nhanvat where idthegioi like '"+idthegioi+"'";
	Nhanvat nv = new Nhanvat ();
	data.open();
	List <Nhanvat> l = new ArrayList <Nhanvat>();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {
	    id = c.getInt(0);
	    int n2 = c.getInt(1);
	    String n3 = c.getString(2)+"";
	    int n4 = c.getInt(3);
	    int n5 = c.getInt(4);
	    String n6 = c.getString(5)+"";
	    String n7 = c.getString(6)+"";
	    String n8 = c.getString(7)+"";
	    nv = new Nhanvat (id,n2,n3,n4,n5,n6,n7,n8);
	    l.add (nv);
	    }while (c.moveToNext());
	}
	data.close ();
	return l;
	}
	
	public void nholoithoai (){
	
	}
	
	public void nhothegioi (){
	
	}
	
	public Loithoai thoaiboisql (String sql){
	int id = 0;
	Loithoai t = new Loithoai ();
	data.open();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {    
	    id = c.getInt (0);
	    int n2 = c.getInt (1);
	    int n3 = c.getInt (2);
	    int n4 = c.getInt (3);
	    String n5 = c.getString (4);
	    String n6 = c.getString (5);
	    int n7 = c.getInt (6);
	    int n8 = c.getInt (7);
	    int n9 = c.getInt (8);
	    t = new Loithoai (id,n2,n3,n4,n5,n6,n7,n8,n9);
	    }while (c.moveToNext());
	}
	data.close();
	return t;
	}
	
    public List <Loithoai> tatcathoaitheothegioi (){
    int id = 0;
	int idthegioi = thegioihientai().getId ();	
	String sql = "select * from Loithoai where idthegioi like '"+idthegioi+"'";
	Loithoai t = new Loithoai ();
	data.open();
	List <Loithoai> l = new ArrayList <Loithoai>();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {    
	    id = c.getInt (0);
	    int n2 = c.getInt (1);
	    int n3 = c.getInt (2);
	    int n4 = c.getInt (3);
	    String n5 = c.getString (4);
	    String n6 = c.getString (5);
	    int n7 = c.getInt (6);
	    int n8 = c.getInt (7);
	    int n9 = c.getInt (8);
	    t = new Loithoai (id,n2,n3,n4,n5,n6,n7,n8,n9);
	    l.add (t);
	    }while (c.moveToNext());
	}
	data.close();
	return l;
    }
	
	public List <Loithoai> tatcathoaibysql (String sql){
    int id = 0;
	int idthegioi = thegioihientai().getId ();	
	//String sql = "select * from Loithoai where idthegioi like '"+idthegioi+"'";
	Loithoai t = new Loithoai ();
	data.open();
	List <Loithoai> l = new ArrayList <Loithoai>();
	Cursor c = data.getData(sql);
	if (c!=null) {
	    do {    
	    id = c.getInt (0);
	    int n2 = c.getInt (1);
	    int n3 = c.getInt (2);
	    int n4 = c.getInt (3);
	    String n5 = c.getString (4);
	    String n6 = c.getString (5);
	    int n7 = c.getInt (6);
	    int n8 = c.getInt (7);
	    int n9 = c.getInt (8);
	    t = new Loithoai (id,n2,n3,n4,n5,n6,n7,n8,n9);
	    l.add (t);
	    }while (c.moveToNext());
	}
	data.close();
	return l;
    }
    
	public Loithoai loithoaidautien (){
	
	List <Loithoai> listThoai = tatcathoaitheothegioi ();
	int min = 1000;	
	for (int i=0; i < (listThoai.size()-1); i++){
	    Loithoai t1 = listThoai.get (i);
	    Loithoai t2 = listThoai.get (i+1);
	    int idnguon1 = t1.getIdnguongoc ();
	    int idnguon2 = t2.getIdnguongoc ();
	    //Tim so be nhat trong 1 list
	    if (idnguon1<idnguon2){
	    if (idnguon1 < min){
	    min = idnguon1;
	    }
	    }else {
	    if(idnguon2 < min) {
	    min = idnguon2;
	    }
	    }    
	}
	String sql = "select * from Loithoai where idnguongoc like '"+min+"'";
	Loithoai t = thoaiboisql (sql);
	return t;
	}
	
	public Loithoai loithoainguon(){	
	int idnguon = getIdthoaihientai ();
	if (idnguon==0){
	idnguon = 1;
	}
	String sql = "select * from Loithoai where id like '"+idnguon+"'";
	Loithoai t = thoaiboisql (sql);
	return t;
	}
	
	public Loithoai loithoaitieptheo (){
	Loithoai thoai = new Loithoai ();
	//idthoai nguon
	int idthoainguon = getIdthoaihientai ();
	//list thoai phu hop
	String sql = "select * from Loithoai where idnguongoc like '"+idthoainguon+"'";
	List <Loithoai> l = tatcathoaibysql(sql);
	    List <Loithoai> list1 = new ArrayList <Loithoai>();	
	    List <Loithoai> list2 = new ArrayList <Loithoai>();
	//tu dong chon thoai phu hop nhat
	for (int i = 0; i < l.size (); i++){
	    Loithoai t = l.get (i);
	    int dk = t.getDieukien ();
	    if(dk==0){
	    // co dk
	    //List <Loithoai> list1 = new ArrayList <Loithoai>();
	    list1.add (t);    
	    }else {
	    // ko co dk
	    //List <Loithoai> list2 = new ArrayList <Loithoai>();
	    list2.add (t);
	    }
	}
	if (l.size() > 0){
	if (list1.size() > 0) {
	// neu co thoai ko dk
	Collections.shuffle(list1);
	thoai = list1.get (0);
	}else {
	// neu ko co thoai ko dk thi kiem tra chi so thuoc tinh co phu hop voi thoai co dk nao trong list2 ko
	Collections.shuffle(list2);
	}
	}
	int idthoaihientaimoi = thoai.getId ();
	setIdthoaihientai(idthoaihientaimoi);
	return thoai;
	}
	
	public void nguoichoichonthoai (){
	//idnguongoc
	//list thoai phu hop
	//nguoi choi chon thoai
	}
	
	public void tinhchiso (){
	
	}
	
	public void tiendonhiemvu (){
	
	}
	
	public void kynangmoi (){
	
	}
	
	public boolean checkUser (){
	boolean status = true;
	data.createDatabase ();
	data.open();
	String sql = "SELECT * FROM Nguoichoithegioi";
	Cursor c = data.getData(sql);
	if (c!=null){
	c.moveToFirst();
	do {
	int id = c.getInt (0);
	if (id>0){
	status = true;
	}else {
	status = false;
	}
	}while (c.moveToNext());
	}
	data.close();
	return status;
	}
	
	public String getTest (){
	String result = "";
	data.createDatabase();
	data.open();
	String sql = "SELECT * FROM Nguoichoi";
	Cursor c = data.getData(sql);
	if (c!=null) {
        c.moveToFirst();
        do {
        String str = c.getInt (0)+" -- ";
        str += c.getString (1)+"";
        result = str;
        }while (c.moveToNext());
        }
	return result;
	
	}
	
}
