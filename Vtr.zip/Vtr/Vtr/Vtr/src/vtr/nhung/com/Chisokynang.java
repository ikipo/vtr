package vtr.nhung.com;

public class Chisokynang
{
private int id,idchiso,idkynang,giatri;

	public Chisokynang()
	{
	}
	
	public Chisokynang(int idchiso, int idkynang, int giatri) {
	this.idchiso = idchiso;
	this.idkynang = idkynang;
	this.giatri = giatri;
	}
	
	public void setId (int id) {this.id = id;}
	public void setIdchiso (int idchiso) {this.idchiso = idchiso;}
	public void setIdkynang (int idkynang) {this.idkynang = idkynang;}
	public void setGiatri (int giatri) {this.giatri = giatri;}
	public int getId (){return this.id;}
	public int getIdchiso (){return this.idchiso;}
	public int getIdkynang (){return this.idkynang;}
	public int getGiatri (){return this.giatri;}
}
