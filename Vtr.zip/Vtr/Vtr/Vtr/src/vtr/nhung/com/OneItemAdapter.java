package vtr.nhung.com;
import vtr.nhung.com.Loithoai;
import android.view.LayoutInflater;
import java.util.List;
import java.lang.String;
import android.widget.TextView;
import android.widget.BaseAdapter;
import java.lang.Override;
import android.view.ViewGroup;
import android.R.layout;
import android.content.Context;
import android.view.View;

public class OneItemAdapter extends BaseAdapter
{
private List <Loithoai> list;
private LayoutInflater layout;
private Context c;
	public OneItemAdapter(Context c, List<Loithoai> list)
	{
	this.c = c;
	this.list = list;
	layout = LayoutInflater.from(c);
	}
	@Override
	public int getCount (){
	return list.size ();
	}
	@Override
	public long getItemId (int i) {
	return i;
	}
	@Override
	public Object getItem (int i) {
	return list.get (i);
	}
	@Override
	public View getView (int i, View v, ViewGroup viewGroup){
	OneItem o;
	if (v==null){
	v = layout.inflate(R.layout.one_item,null);
	o = new OneItem ();
	o.textView = (TextView)v.findViewById(R.id.textView);
	v.setTag(o);
	}else {
	o = (OneItem)v.getTag ();
	}
	Loithoai t = list.get (i);
	String chitiet = t.getChitiet ();
	o.textView.setText (chitiet+"");
	return v;
	}
public class OneItem {
TextView textView;
}
}
