package vtr.nhung.com;

public class Nhanvat
{
private int id, idthegioi, gioitinh, tuoi;
private String ten, nghenghiep, sothich, khongthich;

	public Nhanvat()
	{
	}
	
	public Nhanvat (int id, int idthegioi, String ten, int gioitinh, int tuoi, String nghenghiep, String sothich, String khongthich) {
	this.id = id;
	this.idthegioi = idthegioi;
	this.ten = ten;
	this.gioitinh = gioitinh;
	this.tuoi = tuoi;
	this.nghenghiep = nghenghiep;
	this.sothich = sothich;
	this.khongthich = khongthich;
	}
	
	public int getId (){return this.id;}
	public int getIdthegioi (){return this.idthegioi;}
	public String getTen (){return this.ten;}
	public int getGioitinh (){return this.gioitinh;}
	public int getTuoi (){return this.tuoi;}
	public String getNghenghiep (){return this.nghenghiep;}
	public String getSothich (){return this.sothich;}
	public String getKhongthich (){return this.khongthich;}
	public void setId (int id){this.id = id;}
	public void setIdthegioi (int idthegioi){this.idthegioi = idthegioi;}
	public void setTen (String ten){this.ten = ten;}
	public void setTuoi (int tuoi){this.tuoi = tuoi;}
	public void setNghenghiep (String nghenghiep){this.nghenghiep = nghenghiep;}
	public void setSothich (String sothich){this.sothich = sothich;}
	public void setKhongthich (String khongthich){this.khongthich = khongthich;}
}
