package vtr.nhung.com;

import vtr.nhung.com.ChapterAcitivity;
import vtr.nhung.com.GetData;
import vtr.nhung.com.Thegioi;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;
import android.content.Intent;
import java.lang.Exception;

public class StartActivity extends Activity
{
Button btnXemnguyenvong;
Button btnBatdau;
TextView tv;
Thegioi tg;
	@Override
	public void onCreate(Bundle saveInstanceState) {
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags (WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main4);
	btnXemnguyenvong = (Button)findViewById(R.id.btn_xemnguyenvong);
	btnBatdau = (Button)findViewById(R.id.btn_start);
	tv = (TextView)findViewById(R.id.chapcontent);
	try {
	show ();
	}catch (Exception e){
	Toast.makeText(StartActivity.this,e.getMessage()+"",Toast.LENGTH_LONG).show();
	}
	btnXemnguyenvong.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	    try {
	    String nv = tg.getNguyenvong ();
	    Toast.makeText(StartActivity.this,nv,Toast.LENGTH_LONG).show();
	    }catch (Exception e) {
	    Toast.makeText(StartActivity.this,e.getMessage()+"",Toast.LENGTH_LONG).show();
	    }
	    }
	});
	btnBatdau.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	    //Toast.makeText(StartActivity.this,"Bắt đầu xem cốt truyện",Toast.LENGTH_SHORT).show();
	    if (checkUser ())
	    startActivity(new Intent(StartActivity.this,ChapterAcitivity.class));
	    }
	});
	Toast.makeText(StartActivity.this,"Bắt đầu xem cốt truyện",Toast.LENGTH_SHORT).show();
	}
	
	public void show (){
	GetData data = new GetData (this);
	tg = new Thegioi ();
	tg = data.thegioi ();
	String content = tg.getCottruyen ();
	tv.setText (content);
	}
	
	public boolean checkUser (){
    GetData data = new GetData (this);
    boolean status = data.checkUser ();
    if (status) {
    //Toast.makeText (this,"",Toast.LENGTH_SHORT).show ();
    }
    return status;
    }
}
