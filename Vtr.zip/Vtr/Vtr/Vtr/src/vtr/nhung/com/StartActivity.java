package vtr.nhung.com;
import vtr.nhung.com.ChapterAcitivity;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;
import android.content.Intent;

public class StartActivity extends Activity
{
Button btnXemnguyenvong;
Button btnBatdau;
	@Override
	public void onCreate(Bundle saveInstanceState) {
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags (WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main4);
	btnXemnguyenvong = (Button)findViewById(R.id.btn_xemnguyenvong);
	btnBatdau = (Button)findViewById(R.id.btn_start);
	btnXemnguyenvong.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	    Toast.makeText(StartActivity.this,"Đem cao cao tại thượng Lăng Tuyết nhốt đánh vào bụi bặm, làm nàng thích Lãnh Ngạo không ở chịu Lăng Tuyết bài bố đùa bỡn, còn có vẫn luôn giúp đỡ Lăng Tuyết khi dễ chính mình người, đều phải đã chịu trừng phạt.",Toast.LENGTH_LONG).show();
	    }
	});
	btnBatdau.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	    //Toast.makeText(StartActivity.this,"Bắt đầu xem cốt truyện",Toast.LENGTH_SHORT).show();
	    startActivity(new Intent(StartActivity.this,ChapterAcitivity.class));
	    }
	});
	Toast.makeText(StartActivity.this,"Bắt đầu xem cốt truyện",Toast.LENGTH_SHORT).show();
	}
}
