package vtr.nhung.com;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import java.lang.Override;
import android.database.sqlite.SQLiteDatabase;
public class Mydatabase extends SQLiteOpenHelper
{
public static final String tbUser = "User";
public static final String tbUser_id = "id";
	public Mydatabase(Context c)
	{
	super (c,"mydatabaseVtr",null,1);
	}
	
	@Override
	public void onCreate (SQLiteDatabase db){
	String sql = "CREATE TABLE User "+"("
	                                 +"ID TEXT PRIMARY KEY,"   
	                                 +"TEN TEXT,"   
	                                 +"TUOI INTEGER," 
	                                 +"KINHNGHIEM INTEGER,"  
	                                 +"CAPDO INTEGER," 
	                                 +"MAYMAN INTEGER,"
	                                 +"MILUC INTEGER,"  
	                                 +"VOLUC INTEGER,"  
	                                 +"SOCAP INTEGER,"  
	                                 +"TRUNGCAP INTEGER,"  
	                                 +"CAOCAP INTEGER"  
	                                 +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Character("
	                             +"IDNHANVAT TEXT PRIMARY KEY,"
	                             +"TEN TEXT"
	                             +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Mission("
	                             +"ID TEXT PRIMARY KEY,"
	                             +"TEN TEXT,"
	                             +"IDNHANVATMUCTIEU TEXT,"
	                             +"NGUYENVONG TEXT"
	                             +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Paragraph("
	                             +"ID TEXT PRIMARY KEY,"
	                             +"THELOAI TEXT,"
	                             +"TOMTAT TEXT,"
	                             +"DAYDU TEXT,"
	                             +"NHANVAT TEXT,"
	                             +"IDNHANVAT TEXT,"
	                             +"IDUSER TEXT"
	                             +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Skill("
	                             +"ID TEXT PRIMARY KEY,"
	                             +"IDUSER TEXT,"
	                             +"TEN TEXT,"
	                             +"CHITIET TEXT,"
	                             +"CAPDO INTEGER,"
	                             +"DIEMSOCAP INTEGER,"
	                             +"DIEMTRUNGCAP INTEGER,"
	                             +"DIEMCAOCAP INTEGER"
	                             +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Thuoctinh("
	                             +"ID TEXT PRIMARY KEY,"
	                             +"HACHOA INTEGER,"
	                             +"HAOCAM INTEGER,"
	                             +"TINCAY INTEGER,"
	                             +"HAILONG INTEGER,"
	                             +"MILUC INTEGER,"
	                             +"VOLUC INTEGER,"
	                             +"DANHVONG INTEGER,"
	                             +"GIAUSANG INTEGER,"
	                             +"TINHYEU INTEGER,"
	                             +"HAUCUNG INTEGER,"
	                             +"DAOHOA INTEGER,"
	                             +"XINHDEP INTEGER,"
	                             +"THONGMINH INTEGER,"
	                             +"KHEOLEO INTEGER,"
	                             +"NOITIENG INTEGER,"
	                             +"QUYENLUC INTEGER,"
	                             +"TUDO INTEGER,"
	                             +"TRA INTEGER,"
	                             +"TIEN INTEGER,"
	                             +"BACHLIENHOA INTEGER,"
	                             +"THANHMAU INTEGER,"
	                             +"MARYSURE INTEGER,"
	                             +"THIENTAI INTEGER,"
	                             +"AMAP INTEGER,"
	                             +"NGUYTRANG INTEGER,"
	                             +"NGAYTHO INTEGER"
	                             +")";
	db.execSQL(sql);
	sql = "CREATE TABLE Thuoctinhuser("
	                             +"ID TEXT PRIMARY KEY,"
	                             +"KINHNGHIEM TEXT,"
	                             +"CAPDO INTEGER,"
	                             +"MAYMAN INTEGER,"
	                             +"MILUC INTEGER,"
	                             +"VOLUC INTEGER"
	                             +")";
	db.execSQL(sql);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion ){
	
	}
}
