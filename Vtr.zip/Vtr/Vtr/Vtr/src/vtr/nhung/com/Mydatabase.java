package vtr.nhung.com;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import java.lang.Override;
import android.database.sqlite.SQLiteDatabase;
public class Mydatabase extends SQLiteOpenHelper
{
public static final String tbUser = "User";
public static final String tbUser_id = "id";
	public Mydatabase(Context c)
	{
	super (c,"mydatabaseVtr",null,1);
	}
	
	@Override
	public void onCreate (SQLiteDatabase db){
	String sql = "CREATE TABLE User "+"("
	                                    
	                                    
	                                    
	                                 +")";
	db.execSQL(sql);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion ){
	
	}
}
