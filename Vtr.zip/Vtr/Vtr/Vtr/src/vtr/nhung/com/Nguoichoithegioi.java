package vtr.nhung.com;

public class Nguoichoithegioi
{
private int id, idnguoichoi, idthegioi, idnhanvat, kinhnghiemdatduoc, idthoaihientai;

	public Nguoichoithegioi()
	{
	}
	
	public Nguoichoithegioi(int id, int idnguoichoi, int idthegioi, int idnhanvat, int kinhnghiemdatduoc, int idthoaihientai) {
    this.id = id;
	this.idnguoichoi = idnguoichoi;
	this.idthegioi = idthegioi;
	this.idnhanvat = idnhanvat;
	this.kinhnghiemdatduoc = kinhnghiemdatduoc;
	this.idthoaihientai = idthoaihientai;
	}
	
	public int getId (){return this.id;}
	public int getIdnguoichoi (){return this.idnguoichoi;}
	public int getIdthegioi (){return this.idthegioi;}
	public int getIdnhavat (){return this.idnhanvat;}
	public int getKinhnghiemdatduoc (){return this.kinhnghiemdatduoc;}
	public void setId (int id) {this.id = id;}
	public void setIdnguoichoi (int idnguoichoi) {this.idnguoichoi = idnguoichoi;}
	public void setIdthegioi (int idthegioi) {this.idthegioi = idthegioi;}
	public void setIdnhanvat (int idnhanvat) {this.idnhanvat = idnhanvat;}
	public void setKinhnghiemdatduoc (int kinhnghiemdatduoc) {this.kinhnghiemdatduoc = kinhnghiemdatduoc;}
	public void setIdthoaihientai (int idthoaihientai) {this.idthoaihientai = idthoaihientai;}
	public int getIdthoaihientai (){return this.idthoaihientai;}
}
