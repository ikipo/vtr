package vtr.nhung.com;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.R.string;
import java.lang.Runnable;
import android.os.Handler;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import java.lang.Exception;
import vtr.nhung.com.DataAdapter;
import android.database.Cursor;

public class ChapterAcitivity extends Activity
{
ListView listView;
Button btnBan;
List <String> list;
List <Loithoai> listThoai;
String ban;
OneItemAdapter a;
	@Override
	public void onCreate(Bundle saveInstanceState){
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main5);
	list = new ArrayList <String>();
	listThoai = new ArrayList <Loithoai>();
	//String s = getResources().getString(R.string.p9);
	Loithoai s = thoainguon ();
	listThoai.add (s);
	listView = (ListView)findViewById(R.id.listView);
	btnBan = (Button)findViewById(R.id.btnBan);
	a = new OneItemAdapter (getApplicationContext(),listThoai);
	listView.setAdapter(a);
		
	btnBan.setOnClickListener(new View.OnClickListener (){
	    public void onClick (View v) {
	    showDialog ();
	    	
	        
	    
	    }
	});
    }
    public Loithoai thoainguon (){
    GetData data = new GetData (this);
    Loithoai t = data.loithoainguon();
    return t;
    }
    public void hethongNoi (String s){
    
    }
    public void banNoi (Loithoai t){
    //list.add ('"'+string+'"');
    listThoai.add (t);
    a.notifyDataSetChanged();
    listView.smoothScrollByOffset(a.getCount());
    }
    public void waitForHethong (final Loithoai t){
    Handler h = new Handler ();
    h.postDelayed(new Runnable (){
        public void run (){        
        listThoai.add (t);
        a.notifyDataSetChanged();
        listView.smoothScrollByOffset(a.getCount());
        }
    },1000);
    }
    public void showDialog (){
    final Dialog dialog = new Dialog (ChapterAcitivity.this);
    dialog.getWindow().setBackgroundDrawable(new ColorDrawable (Color.WHITE));
    dialog.setContentView(R.layout.customalertdialog);
    ListView lv = (ListView)dialog.findViewById(R.id.lv);
    String s4 = getResources().getString (R.string.p6);
    List <Loithoai> listChoice = new ArrayList <Loithoai>();
    final GetData data = new GetData (this);
    listChoice = data.listnguoichoichonthoai ();
    //listChoice.add (s4);
    //listChoice.add (s4);
    //listChoice.add (s4);
    //listChoice.add (s4);
    //listChoice.add (s4);
    OneItemAdapter a = new OneItemAdapter (ChapterAcitivity.this,listChoice);
    lv.setAdapter(a);
    dialog.setCancelable(true);
    dialog.setTitle("Vtr");
    dialog.show ();
    
    lv.setOnItemClickListener(new AdapterView.OnItemClickListener (){
        @Override
        public void onItemClick (AdapterView <?> parent, View view, int position, long id) {
        ////Toast.makeText (ChapterAcitivity.this, "", Toast.LENGTH_SHORT).show ();
        Loithoai choice = (Loithoai)parent.getItemAtPosition(position);
        data.nguoichoichonthoai (choice.getId ());
        ////Toast.makeText (ChapterAcitivity.this, choice, Toast.LENGTH_SHORT).show ();
        banNoi(choice);
        dialog.dismiss();
        Loithoai t = data.loithoaitieptheo ();
        //String s3 = getResources().getString (R.string.p5);
        waitForHethong (t);
        //listThoai.add (choice);
        }
    });
    //testData2 ();
    }
    
    public void testData2 (){
    GetData data = new GetData (this);
    Loithoai t = data.loithoaitieptheo();
    String id = t.getChitiet ()+ "";
    String thoai = data.getIdthoaihientai () + "";
    Toast.makeText(this,id,Toast.LENGTH_SHORT).show();
    Toast.makeText(this,"thoainguon" + thoai,Toast.LENGTH_SHORT).show();
    }    
    
    public boolean checkUser (){
    GetData data = new GetData (this);
    boolean status = data.checkUser ();
    if (status) {
    Toast.makeText (this,"login",Toast.LENGTH_SHORT).show ();
    }
    return status;
    }
    
    @Override
    public void onStop(){
    GetData data = new GetData (this);
    super.onDestroy();
    }
}
