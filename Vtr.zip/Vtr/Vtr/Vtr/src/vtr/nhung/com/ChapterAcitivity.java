package vtr.nhung.com;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.R.string;
import java.lang.Runnable;
import android.os.Handler;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import java.lang.Exception;
import vtr.nhung.com.DataAdapter;
import android.database.Cursor;

public class ChapterAcitivity extends Activity
{
ListView listView;
Button btnBan;
List <String> list;
String ban;
OneItemAdapter a;
	@Override
	public void onCreate(Bundle saveInstanceState){
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main5);
	list = new ArrayList <String>();
	String s = getResources().getString(R.string.p9);
	list.add (s);
	listView = (ListView)findViewById(R.id.listView);
	btnBan = (Button)findViewById(R.id.btnBan);
	a = new OneItemAdapter (getApplicationContext(),list);
	listView.setAdapter(a);
		
	btnBan.setOnClickListener(new View.OnClickListener (){
	    public void onClick (View v) {
	    showDialog ();
	    	
	        
	    
	    }
	});
    }
    public void hethongNoi (String s){
    
    }
    public void banNoi (String string ){
    list.add ('"'+string+'"');
    a.notifyDataSetChanged();
    listView.smoothScrollByOffset(a.getCount());
    }
    public void waitForHethong (final String string){
    Handler h = new Handler ();
    h.postDelayed(new Runnable (){
        public void run (){
        list.add ('"'+string+'"');
        a.notifyDataSetChanged();
        listView.smoothScrollByOffset(a.getCount());
        }
    },1000);
    }
    public void showDialog (){
    final Dialog dialog = new Dialog (ChapterAcitivity.this);
    dialog.getWindow().setBackgroundDrawable(new ColorDrawable (Color.WHITE));
    dialog.setContentView(R.layout.customalertdialog);
    ListView lv = (ListView)dialog.findViewById(R.id.lv);
    String s4 = getResources().getString (R.string.p6);
    List <String> listChoice = new ArrayList <String>();
    listChoice.add (s4);
    listChoice.add (s4);
    listChoice.add (s4);
    listChoice.add (s4);
    listChoice.add (s4);
    OneItemAdapter a = new OneItemAdapter (ChapterAcitivity.this,listChoice);
    lv.setAdapter(a);
    dialog.setCancelable(true);
    dialog.setTitle("Vtr");
    dialog.show ();
    
    lv.setOnItemClickListener(new AdapterView.OnItemClickListener (){
        @Override
        public void onItemClick (AdapterView <?> parent, View view, int position, long id) {
        //Toast.makeText (ChapterAcitivity.this, "", Toast.LENGTH_SHORT).show ();
        String choice = (String)parent.getItemAtPosition(position);
        //Toast.makeText (ChapterAcitivity.this, choice, Toast.LENGTH_SHORT).show ();
        banNoi(choice);
        dialog.dismiss();
        String s3 = getResources().getString (R.string.p5);
        waitForHethong (s3);
        }
    });
    testDb ();
    }
    
    public void testDb (){
    try {
        DataAdapter data = new DataAdapter (this);
        data.createDatabase();
        data.open();     
        Cursor c = data.getData ();
        if (c!=null) {
        c.moveToFirst();
        do {
        String str = c.getInt (0)+" -- ";
        str += c.getString (2)+"";
        Toast.makeText (this,str,Toast.LENGTH_SHORT).show ();
        }while(c.moveToNext());
        }
        data.close ();
        }catch (Exception e){
        Toast.makeText (this,e.getMessage().toString(),Toast.LENGTH_SHORT).show ();        
        }
    }
}
