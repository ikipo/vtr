package vtr.nhung.com;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.R.string;
import java.lang.Runnable;
import android.os.Handler;

public class ChapterAcitivity extends Activity
{
ListView listView;
Button btnBan;
List <String> list;
	@Override
	public void onCreate(Bundle saveInstanceState){
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main5);
	list = new ArrayList <String>();
	String s = getResources().getString(R.string.p9);
	list.add (s);
	listView = (ListView)findViewById(R.id.listView);
	btnBan = (Button)findViewById(R.id.btnBan);
	final OneItemAdapter a = new OneItemAdapter (getApplicationContext(),list);
	listView.setAdapter(a);
		
	btnBan.setOnClickListener(new View.OnClickListener (){
	    public void onClick (View v) {
	    String s2 = getResources().getString(R.string.p6);
	    String s3 = getResources().getString(R.string.p5);	    	    
	    list.add ('"'+s2+'"');	    
	    a.notifyDataSetChanged();
	    waitForHethong (a,list,s3);    
	    listView.smoothScrollByOffset(a.getCount());    
	    }
	});
    }
    public void banNoi(String s){
    
    }
    public void hethongNoi (String s){
    
    }
    public void waitForHethong (final OneItemAdapter adapter, final List <String> l, final String string){
    Handler h = new Handler ();
    h.postDelayed(new Runnable (){
        public void run (){
        l.add ('"'+string+'"');
        adapter.notifyDataSetChanged();
        listView.smoothScrollByOffset(adapter.getCount());
        }
    },1000);
    }
}
