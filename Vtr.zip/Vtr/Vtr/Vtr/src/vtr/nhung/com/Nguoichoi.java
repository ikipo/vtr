package vtr.nhung.com;

public class Nguoichoi
{
private int id,tuoi,kinhnghiem,idthegioihientai;
private String ten;

	public Nguoichoi()
	{
	}
	
	public Nguoichoi (String ten, int tuoi, int kinhnghiem, int idthegioihientai) {
	this.ten = ten;
	this.tuoi = tuoi;
	this.kinhnghiem = kinhnghiem;
	this.idthegioihientai = idthegioihientai;
	}
	
	public int getId (){return this.id;}
	public String getTen (){return this.ten;}
	public int getTuoi (){return this.tuoi;}
	public int getKinhnghiem (){return this.kinhnghiem;}
	public int getIdthegioihientai (){return this.idthegioihientai;}
	public void setTen (String ten) {this.ten = ten;}
	public void setTuoi (int tuoi) {this.tuoi = tuoi;}
	public void setKinhnghiem (int kinhnghiem) {this.kinhnghiem = kinhnghiem;}
	public void setIdthegioihientai (int idthegioihientai) {this.idthegioihientai = idthegioihientai;}	
}
