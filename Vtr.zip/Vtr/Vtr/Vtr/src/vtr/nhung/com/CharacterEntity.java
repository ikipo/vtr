package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;

public class CharacterEntity
{
private String idnhanvat;
private String ten;
// Thuoc tinh
private ThuoctinhEntity thuoctinh;

	public CharacterEntity()
	{
	this.idnhanvat = "";
	this.ten = "";
	this.thuoctinh = new ThuoctinhEntity (idnhanvat);
	}
	public void ChatacterEntity (String idnhanvat, String ten, ThuoctinhEntity thuoctinh){
	this.idnhanvat = idnhanvat;
	this.ten = ten;
	this.thuoctinh = thuoctinh;
	}
	public void setIdnhanvat (String id){this.idnhanvat = idnhanvat;}
	public void setTen (String ten){this.ten = ten;}
	public void setThuoctinh (ThuoctinhEntity thuoctinh){this.thuoctinh = thuoctinh;}
	public String getIdnhanvat (){return idnhanvat;}
	public String getTen (){return ten;}
	public ThuoctinhEntity getThuoctinh (){	return thuoctinh;	}
}
