package vtr.nhung.com;

public class CharacterEntity
{
private String idnhanvat;
private String ten;
// Thuoc tinh
private int hachoa;
private int haocam;
private int tincay;
private int hailong;
private int miluc;
private int voluc;
private int danhvong;
private int giausang;
private int tinhyeu;
private int haucung;
private int daohoa;
private int xinhdep;
private int thongminh;
private int kheoleo;
private int noitieng;
private int quyenluc;
private int tudo;
private int tra;
private int tien;
private int bachlienhoa;
private int thanhmau;
private int marysure;
private int thientai;
private int amap;
private int nguytrang;
private int ngaytho;
	public CharacterEntity()
	{
	}
}
