package vtr.nhung.com;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;

import java.lang.Override;

public class VtrActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.main);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable (){
            public void run (){
            Intent intent = new Intent (VtrActivity.this,MainActivity.class);
            startActivity (intent);
            }
        },1000);
    }
    @Override
    public void onResume() {
    super.onResume();
    Handler handler= new Handler ();
    handler.postDelayed(new Runnable (){
      public void run (){
      finish ();
      }
    },1000);
    }
}
