package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;
import vtr.nhung.com.ThuoctinhuserEntity;

public class ParagraphEntity
{
private String id;
private String theloai; //vd:thoai,kechuyen...
private String tomtat;
private String daydu;
private String nhanvat;
private String idnhanvat;
private String iduser;
// Danh sach cho diem thuoc tinh cua nguoi choi
private ThuoctinhuserEntity chodiemuser;
// Danh sach cho diem cam nhan cua nhan vat muc tieu
private ThuoctinhEntity chodiemnpc;
private ThuoctinhEntity dieukienthuoctinh;
	public ParagraphEntity()
	{
	this.id = "";
	this.theloai = "";
	this.tomtat = "";
	this.daydu = "";
	this.nhanvat = "";
	this.idnhanvat = "";
	this.iduser = "";
	this.chodiemuser = new ThuoctinhuserEntity ("chodiemuser"+id);
	this.chodiemnpc = new ThuoctinhEntity ("chodiemnpc"+id);
	this.dieukienthuoctinh = new ThuoctinhEntity (id);
	}
	public void ParagraphEntity (String id, String theloai, String tomtat, String daydu, String nhanvat, String idnhanvat, String iduser, ThuoctinhEntity dieukienthuoctinh, ThuoctinhEntity chodiemnpc){
	this.id = id;
	this.theloai = theloai;
	this.tomtat = tomtat;
	this.daydu = daydu;
	this.nhanvat = nhanvat;
	this.idnhanvat = idnhanvat;
	this.iduser = iduser;
	this.chodiemnpc = chodiemnpc;
	this.chodiemuser = chodiemuser;
	this.dieukienthuoctinh = dieukienthuoctinh;
	}
	public void setId (String id) {this.id = id;}
	public void setTheloai (String theloai) {this.theloai = theloai;}
	public void setTomtat (String tomtat) {this.tomtat = tomtat;}
	public void setDaydu (String daydu) {this.daydu = daydu;}
	public void setNhanvat (String nhanvat) {this.nhanvat = nhanvat;}
	public void setIdnhanvat (String idnhanvat) {this.idnhanvat = idnhanvat;}
	public void setIduser (String iduser) {this.iduser = iduser;}
	public void setChodiemuser (ThuoctinhuserEntity chodiemuser) {this.chodiemuser = chodiemuser;}
	public void setChodiemnpc (ThuoctinhEntity chodiemnpc) {this.chodiemnpc = chodiemnpc;}
	public void setDieukienthuoctinh (ThuoctinhEntity dieukienthuoctinh) {this.dieukienthuoctinh = dieukienthuoctinh;}
    public String getId (){return id;}
    public String getTheloai (){return theloai;}
    public String getTomtat (){return tomtat;}
    public String getDaydu (){return daydu;}
    public String getNhanvat (){return nhanvat;}
    public String getIdnhanvat (){return idnhanvat;}
    public String getIduser (){return iduser;}
	public ThuoctinhEntity getChodiemnpc (){	return chodiemnpc;	}
	public ThuoctinhuserEntity getChodiemuser (){	return chodiemuser;	}
	public ThuoctinhEntity getDieukienthuoctinh (){	return dieukienthuoctinh;	}
}
