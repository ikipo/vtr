package vtr.nhung.com;
import vtr.nhung.com.ThuoctinhEntity;
import vtr.nhung.com.ThuoctinhuserEntity;

public class ParagraphEntity
{
private String id;
private String theloai; //vd:thoai,kechuyen...
private String tomtat;
private String daydu;
private String nhanvat;
private String idnhanvat;
private String iduser;
// Danh sach cho diem thuoc tinh cua nguoi choi
private ThuoctinhuserEntity chodiemuser;
// Danh sach cho diem cam nhan cua nhan vat muc tieu
private ThuoctinhEntity chodiemnpc;
private ThuoctinhEntity dieukienthuoctinh;
	public ParagraphEntity()
	{
	this.id = "";
	this.theloai = "";
	this.tomtat = "";
	this.daydu = "";
	this.nhanvat = "";
	this.idnhanvat = "";
	this.iduser = "";
	this.chodiemuser = new ThuoctinhuserEntity (id);
	this.chodiemnpc = new ThuoctinhEntity ("chodiemnpc"+id);
	this.dieukienthuoctinh = new ThuoctinhEntity ("chodiemuser"+id);
	}
	public void ParagraphEntity (ThuoctinhEntity dieukienthuoctinh, ThuoctinhEntity chodiemnpc){
	this.chodiemnpc = chodiemnpc;
	this.chodiemuser = chodiemuser;
	this.dieukienthuoctinh = dieukienthuoctinh;
	}
	public ThuoctinhEntity getChodiemnpc (){	return chodiemnpc;	}
	public ThuoctinhuserEntity getChodiemuser (){	return chodiemuser;	}
	public ThuoctinhEntity getDieukienthuoctinh (){	return dieukienthuoctinh;	}
}
