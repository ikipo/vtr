package vtr.nhung.com;

public class ParagraphEntity
{
private String id;
private String theloai; //vd:thoai,kechuyen...
private String tomtat;
private String daydu;
private String nhanvat;
private String idnhanvat;
// Danh sach cho diem thuoc tinh cua nguoi choi
private int userkinhnghiem;
private int usermayman;
private int usermiluc;
private int uservoluc;
// Danh sach cho diem cam nhan cua nhan vat muc tieu
private int hachoa;
private int haocam;
private int tincay;
private int hailong;
private int miluc;
private int voluc;
private int danhvong;
private int giausang;
private int tinhyeu;
private int haucung;
private int daohoa;
private int xinhdep;
private int thongminh;
private int kheoleo;
private int noitieng;
private int quyenluc;
private int tudo;
private int tra;
private int tien;
private int bachlienhoa;
private int thanhmau;
private int marysure;
private int thientai;
private int amap;
private int nguytrang;
private int ngaytho;
	public ParagraphEntity()
	{
	}
}
