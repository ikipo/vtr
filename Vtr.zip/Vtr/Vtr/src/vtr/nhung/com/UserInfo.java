package vtr.nhung.com;

public class UserInfo
{
	public UserInfo()
	{
	}
}
