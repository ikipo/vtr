package vtr.nhung.com;
import java.lang.Override;
import android.app.*;
import android.os.Bundle;
import android.R.layout;
import android.widget.*;
import android.view.*;

public class ChapterAcitivity extends Activity
{
	@Override
	public void onCreate(Bundle saveInstanceState){
	super.onCreate(saveInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	setContentView(R.layout.main5);
	}
}
